package geyer.location.android.peglog;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class database {

    private final static String keyRowId = "_id";
    private final static String Latitude = "Latitude";
    private final static String Longitude = "Longitude";
    private final static String Accuracy = "accuracy";
    private final static String Timestamp = "timeStamp";
    private final static String databaseName = "locationData";
    private final static String databaseTable = "locationDataTable";

    private final static int databaseVersion = 1;

    private DbHelper databaseHelper;
    private SQLiteDatabase locationDatabase;

    private final Context context;

    public database(Context context) {
        this.context = context;
    }

    public long addEntry(double myLatitude, double myLongitude, float myAccuracy, long myTime) {

        Log.i("database", "added: " + myLatitude + " - " + myLongitude +" - " + myAccuracy + " - " + myTime);
        ContentValues contentValues = new ContentValues();
        contentValues.put(Latitude, myLatitude);
        contentValues.put(Longitude, myLongitude);
        contentValues.put(Accuracy, myAccuracy);
        contentValues.put(Timestamp, myTime);
        return locationDatabase.insert(databaseTable, null, contentValues);
    }

    public ArrayList<Double> getLatitudes() {
        String [] columns = new String[]{keyRowId, Latitude, Longitude, Accuracy, Timestamp};

        Cursor c = locationDatabase.query(databaseTable, columns, null, null, null, null, null);

        int iLat = c.getColumnIndex(Latitude);
        ArrayList<Double> databaseLatitudes = new ArrayList<Double>();
        for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()){
            databaseLatitudes.add(c.getDouble(iLat));
        }

        return databaseLatitudes;

    }

    public ArrayList<Double> getLongitudes() {
        String [] columns = new String[]{keyRowId, Latitude, Longitude, Accuracy, Timestamp};

        Cursor c = locationDatabase.query(databaseTable, columns, null, null, null, null, null);

        int iLong = c.getColumnIndex(Longitude);
        ArrayList<Double> databaseLongitude = new ArrayList<Double>();
        for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()){
            databaseLongitude.add(c.getDouble(iLong));
        }

        return databaseLongitude;
    }

    public ArrayList<Long> getTimes() {
        String [] columns = new String[]{keyRowId, Latitude, Longitude, Accuracy, Timestamp};
        Cursor c = locationDatabase.query(databaseTable, columns, null, null, null, null, null);

        int iTime = c.getColumnIndex(Timestamp);
        ArrayList<Long> databaseTime = new ArrayList<Long>();
        for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()){
            databaseTime.add(c.getLong(iTime));
        }
        if((databaseTime.size()-1)>0){
            Log.i("returning time", "" + databaseTime.get(databaseTime.size()-1));
        }else{
            Log.i("returning time", "No time point accessiable");
        }


        return databaseTime;
    }

    public ArrayList<Float> getAccuracy() {
        String [] columns = new String[]{keyRowId, Latitude, Longitude, Accuracy, Timestamp};
        Cursor c = locationDatabase.query(databaseTable, columns, null, null, null, null, null);

        int iAccuracy = c.getColumnIndex(Accuracy);
        ArrayList<Float> databaseAccuracy = new ArrayList<>();
        for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()){
            databaseAccuracy.add(c.getFloat(iAccuracy));
        }
        return databaseAccuracy;
    }

    public String getLastReading() {
        String lastReading;

        String [] columns = new String[]{keyRowId, Latitude, Longitude, Accuracy, Timestamp};
        Cursor c = locationDatabase.query(databaseTable, columns, null, null, null, null, null);

        int iLat = c.getColumnIndex(Latitude);
        int iLong = c.getColumnIndex(Longitude);
        int iAccuracy = c.getColumnIndex(Accuracy);
        int iTime = c.getColumnIndex(Timestamp);

        c.moveToLast();
        lastReading = "lat: " + c.getDouble(iLat) +
        "; long: " + c.getDouble(iLong) +
        "; accuracy(meters): " + c.getFloat(iAccuracy) +
        "; time(unix): " + c.getLong(iTime) + ".";

        return lastReading;
    }

    private class DbHelper extends SQLiteOpenHelper {

        public DbHelper(Context context) {
            super(context, databaseName, null, databaseVersion);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE " + databaseTable + " ("
                    + keyRowId + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + Latitude + " REAL,"
                    + Longitude +  " REAL,"
                    + Accuracy + " REAL,"
                    + Timestamp + " INTEGER);"
            );
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + databaseTable);
            onCreate(db);
        }
    }

    public database open() throws SQLException {
        databaseHelper = new DbHelper(context);
        locationDatabase = databaseHelper.getWritableDatabase();
        return this;
    }

    public long getDatabaseSize(){
        SQLiteDatabase readableDB = databaseHelper.getReadableDatabase();
        return DatabaseUtils.queryNumEntries(readableDB, databaseTable);
    }

    public void close() {
        databaseHelper.close();
    }
}

