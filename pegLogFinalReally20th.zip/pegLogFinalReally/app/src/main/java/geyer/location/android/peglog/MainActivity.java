package geyer.location.android.peglog;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * The code contained within this activity is divided up between what is up to the participant to call for and
 * what the application will call for. All aspects which the participant will call for are referred to as UI.
 * If the section is not marked UI then assume that this is necessary functions for the application to operate.
 */

public class MainActivity extends Activity implements View.OnClickListener {

    //components for handling data which is not deleted with activity related to the operation of the app
    SharedPreferences mainPreferences;
    SharedPreferences.Editor editor;

    //ID for particular permission calls.
    private static final int MY_PERMISSION_REQUEST_ALL_PERMISSIONS = 101;
    private static final int MY_PERMISSION_REQUEST_FINE_LOCATION = 102;
    private static final int MY_PERMISSION_REQUEST_READ_PHONE_STATE = 103;

    //used to relay the status of data collection
    TextView statusTV;

    //on start:


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    //initialize ui components
        initializeVisibleComponents();
    //initialize components required for central operations
        initializeInvisibleComponents();
    //initialize the application for background recording.
        readyToRecord();
    }

    /**
     * UI section
     */

    private void initializeVisibleComponents() {
        //ui components initialization
        Button emailMe = findViewById(R.id.emailBtn);
        emailMe.setOnClickListener(this);

        Button report = findViewById(R.id.btnReport);
        report.setOnClickListener(this);
        statusTV = findViewById(R.id.statusTV);
    }


    //handles button presses
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.emailBtn:
                startActivity(new Intent(this, uploadProgress.class));
                break;
            case R.id.btnReport:
                reportLastDataPoint();
                break;
        }
    }

    //surveys the SQLite database in order to return the last known data entry for the location database
    private void reportLastDataPoint() {
        database db = new database(this);
        db.open();

        String toToast =  db.getLastReading();
        db.close();

        Toast.makeText(this, "last reading: - " + toToast, Toast.LENGTH_LONG).show();
    }

    /**
     * initializing permissions and recording
     */

    private void initializeInvisibleComponents() {
        //initializing shared preferences
        mainPreferences = getSharedPreferences("Data collection", Context.MODE_PRIVATE);
        editor = mainPreferences.edit();
        editor.apply();

        //initializing the receiver that gets input from background processes
        LocalBroadcastManager.getInstance(this).registerReceiver(dataCollectionInitiated, new IntentFilter("changeInService"));
    }

    //this method ensures that all the appropriate user behaviours are carried out before logging begins including (in order):
        //generating a password
        //giving permissions:
            //location
            //phone state
    private void readyToRecord() {
        if(mainPreferences.getBoolean("password generated", false)){
            if(Build.VERSION.SDK_INT < Build.VERSION_CODES.M){
                collectData();
            }
            else {
                initializeApp();
            }
        }else{
            requestPassword();
        }
    }

    //requests the password from the participant. Gets called again if the password is not longer than 8 characters
    private void requestPassword() {
        LayoutInflater inflater = this.getLayoutInflater();
        //create dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("password")
                .setMessage("The file that is generated with your data and later exported must be password protected. Please enter a password that is longer than 8 characters")
                .setView(inflater.inflate(R.layout.alert_dialog_et, null))
                .setNeutralButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                    Dialog d = (Dialog) dialogInterface;
                                EditText password = d.findViewById(R.id.etPassword);
                                if(checkPassword(password.getText())){
                                   editor.putBoolean("password generated", true);
                                       editor.putString("password", String.valueOf(password.getText()));
                                   editor.apply();
                                   readyToRecord();
                                }else{
                                    readyToRecord();
                                    Toast.makeText(MainActivity.this, "The password entered was not long enough", Toast.LENGTH_SHORT).show();
                                }
                            }

                    private boolean checkPassword(Editable text) {
                        return text.length() > 7;
                    }
                });
        builder.create()
                .show();
    }

    //Identifies which permissions have been given and requests the dangerous permissions which have not.
    public void initializeApp() {
        //determines if both permissions are required
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED){
            //requests both permissions
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.READ_PHONE_STATE},
                    MY_PERMISSION_REQUEST_ALL_PERMISSIONS);
        }
        //if just the location permission isn't granted
        else if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            //requests the location permission
            ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSION_REQUEST_FINE_LOCATION);
        }
        //if just the phone state permission isn't granted
        else if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED){
            //requests the phone state permission
                ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.READ_PHONE_STATE},
                        MY_PERMISSION_REQUEST_READ_PHONE_STATE);
        }
        //if all relevant permissions are granted then start the services
        else{
            collectData();
        }
    }

    //handle the result of the requests for permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSION_REQUEST_ALL_PERMISSIONS:
                if(grantResults.length > 0){
                    if(grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED){
                        collectData();
                    }else{
                        Toast.makeText(this, "Location permissions and phone state permissions are required to participate in the experiment", Toast.LENGTH_SHORT).show();
                        initializeApp();
                    }
                }else{
                    initializeApp();
                }
                break;
            case MY_PERMISSION_REQUEST_FINE_LOCATION:
                if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    initializeApp();
                }else{
                    Toast.makeText(this, "To participate in the study you must give location permission", Toast.LENGTH_SHORT).show();
                    initializeApp();
                }
                break;
            case MY_PERMISSION_REQUEST_READ_PHONE_STATE:
                if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    initializeApp();
                }else{
                    Toast.makeText(this, "To participate in the study you must give read phone state permission. This is required so we can identify what might be wrong with the location sensing", Toast.LENGTH_SHORT).show();
                    initializeApp();
                }
                break;
        }
    }

    //starts the background operations
    private void collectData() {
        //detecting if background operations have previously been requested to run.
        if(!mainPreferences.getBoolean("fuseLocationClient running", false)){
            //start the background operations
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                startService(new Intent(this, fuseLocationClient.class));
            }else {
                startForegroundService(new Intent(this, fuseLocationClient.class));
            }
        }
    }

    //relays data sent from background operations to the user.
    private BroadcastReceiver dataCollectionInitiated = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getBooleanExtra("locationDataCollectionBegan", false)){
                String toRelay = intent.getStringExtra("Status");
                String toShow ="Status: " + "\n" +
                            toRelay;

                    statusTV.setText(toShow);
                    statusTV.setGravity(Gravity.CENTER);
            }
        }
    };


    //final call before activity is destroyed
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}

