package geyer.location.android.peglog;

import com.google.android.gms.location.LocationRequest;

public final class Constants {

    // Milliseconds per second
    private static final int MILLISECONDS_PER_SECOND = 1000;
    // The fastest update frequency, in seconds
    private static final int FASTEST_INTERVAL_IN_SECONDS = 15;
    // A fast frequency ceiling in milliseconds
    static final long FASTEST_INTERVAL = MILLISECONDS_PER_SECOND * FASTEST_INTERVAL_IN_SECONDS;
    //File name of the error log
    static final String ERROR_FILE_NAME = "ErrorData.pdf";
    //Fle name of the location data
    static final String TO_ENCRYPT_FILE = "locationData.pdf";
    //setting the level of accuracy that the application works
    static final int ACCURACY_LEVEL = LocationRequest.PRIORITY_HIGH_ACCURACY;
}
