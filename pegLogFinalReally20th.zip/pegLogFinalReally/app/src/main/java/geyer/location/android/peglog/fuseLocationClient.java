package geyer.location.android.peglog;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Objects;

public class fuseLocationClient extends Service {

    //values for location provider
    FusedLocationProviderClient fusedLocationProviderClient;
    LocationRequest locationRequest;

    //values for determining if Runnables are running
    private boolean fileSizeAssessmentUnderway;
    private boolean diagnosisRunnableRunning;

    //handles the operating of Runnables
    private Handler generalHandler;

    //sharedPreferences values
    private SharedPreferences servicePreferences;
    private SharedPreferences.Editor editor;

    //broadcast receiver
    BroadcastReceiver generalReceiver;
    BroadcastReceiver screenReceiver;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //ensures service is running in foreground
        startForegroundOperations();
        //initializes global values
        initializeValues();

        Bundle b = intent.getExtras();
        if(b != null){
            if(b.getBoolean("phone restarted")){
                storeErrorInSQL("Phone restarted");
            }
        }
        //documents that the service is operational to internal memory and shared preferences
        documentServiceStart();
        //determines if a google play update is required in order to access location updates
        if (detectGooglePlayUpdateRequired()) {
            sendMessageToMain("To participate in the study, you are required to update your google play account");
            //insert additional code here
        }
        //initialize the location updates
        initializeLocationUpdate();
        //
        initializeRelevantPermissionsUpdate();
        return START_STICKY;
    }

    //This method across SDK versions calls for a foreground service
    private void startForegroundOperations() {
        if (Build.VERSION.SDK_INT >= 26) {
            if (Build.VERSION.SDK_INT > 26) {
                String CHANNEL_ONE_ID = "sensor.example. geyerk1.inspect.screenservice";
                String CHANNEL_ONE_NAME = "Screen service";
                NotificationChannel notificationChannel = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    notificationChannel = new NotificationChannel(CHANNEL_ONE_ID,
                            CHANNEL_ONE_NAME, NotificationManager.IMPORTANCE_MIN);
                    notificationChannel.enableLights(true);
                    notificationChannel.setLightColor(Color.RED);
                    notificationChannel.setShowBadge(true);
                    notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                    NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    manager.createNotificationChannel(notificationChannel);
                }

                Bitmap icon = BitmapFactory.decodeResource(getResources(), R.drawable.ic_location);
                Notification notification = new Notification.Builder(getApplicationContext())
                        .setChannelId(CHANNEL_ONE_ID)
                        .setContentTitle("Recording data")
                        .setContentText("Peg Log is logging data")
                        .setSmallIcon(R.drawable.ic_location)
                        .setLargeIcon(icon)
                        .build();

                Intent notificationIntent = new Intent(getApplicationContext(), geyer.location.android.peglog.MainActivity.class);
                notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                notification.contentIntent = PendingIntent.getActivity(getApplicationContext(), 0, notificationIntent, 0);

                startForeground(101, notification);
            } else {
                startForeground(101, updateNotification());
            }
        } else {
            Intent notificationIntent = new Intent(this, MainActivity.class);

            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                    notificationIntent, 0);

            Notification notification = new NotificationCompat.Builder(this)
                    .setSmallIcon(R.drawable.peg_icon)
                    .setContentTitle("Recording data")
                    .setContentText("Peg Log is logging data")
                    .setContentIntent(pendingIntent).build();

            startForeground(101, notification);
        }

    }

    private Notification updateNotification() {

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, geyer.location.android.peglog.MainActivity.class), 0);

        return new NotificationCompat.Builder(this)
                .setContentTitle("Activity log")
                .setTicker("Ticker")
                .setContentText("data recording a is on going")
                .setSmallIcon(R.drawable.ic_location)
                .setContentIntent(pendingIntent)
                .setOngoing(true).build();
    }

    //values employed are initialized
    private void initializeValues() {
        //booleans which handle if runnable is operating
        diagnosisRunnableRunning = false;
        fileSizeAssessmentUnderway = false;
        //handler for the Runnable
        generalHandler = new Handler();
        //sharedPreferences
        servicePreferences = getSharedPreferences("Data collection", Context.MODE_PRIVATE);
        editor = servicePreferences.edit();

        if(servicePreferences.getBoolean("kill main", false)){
            sendMessageToMain("kill main");
            editor.putBoolean("kill main", false);
            editor.apply();
        }
    }

    //documents in shared preferences that service has started
    private void documentServiceStart() {
        Log.i("screenService", "started running");
        editor.putBoolean("fuseLocationClient running", true);
        editor.apply();
        storeErrorInSQL("Documenting start of recording");
    }

    //attempts to initialize fuseLocationProviderClient and call location updates.
    //on failure, diagnostics are run, errors logged and sent to main
    private void initializeLocationUpdate() {
        try {
            fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
            getLocation();
        } catch (Exception e) {
            Log.e("fuseLocationClient", "Can't initialize location updates: " + e);
            sendMessageToMain("Can't initialize location updates: " + e);
            generalHandler.postDelayed(reinitializeLocation,  1000);
        }
        Log.i("fuseLocationClient", "started");
    }

    //initializes the relevant permission updates and if screen is off and if date changed
    private void initializeRelevantPermissionsUpdate() {
        generalReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    switch (Objects.requireNonNull(intent.getAction())) {
                        case Intent.ACTION_AIRPLANE_MODE_CHANGED:
                            storeErrorInSQL("Airplane mode changed");
                            Log.i("permissionsChanged", "airplane Mode Changed");
                            generalHandler.postDelayed(reinitializeLocation, 1000);
                            break;
                        case Intent.ACTION_DATE_CHANGED:
                            makeScreenReceiver();
                            Log.i("date changed", "need to restart service");
                            break;
                    }
                }
            }
        };
        IntentFilter permissionReceiverFilter = new IntentFilter();

        permissionReceiverFilter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        permissionReceiverFilter.addAction(Intent.ACTION_DATE_CHANGED);
        //find a way of detecting changes in location permissions
        registerReceiver(generalReceiver, permissionReceiverFilter);
    }

    private void makeScreenReceiver() {
        screenReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if(intent.getAction() != null){
                    switch (intent.getAction()){
                        case Intent.ACTION_SCREEN_OFF:
                            Log.i("screen off", "true");
                                sendMessageToMain("Restart service");
                                editor.putBoolean("need to restart service", false);
                                editor.apply();
                            break;
                    }
                }
            }
        };

        IntentFilter screenReceiverFilter = new IntentFilter();
                screenReceiverFilter.addAction(Intent.ACTION_SCREEN_OFF);

                registerReceiver(screenReceiver, screenReceiverFilter);
    }

    //attempts to set up location recording
    //on failure, diagnostics are run
    private void getLocation() {
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(60000)
                .setFastestInterval(60000)
                .setPriority(Constants.ACCURACY_LEVEL);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {
            generalHandler.postDelayed(reinitializeLocation, 1000);
        }else{
            try{
                fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, getMainLooper());
            }catch (Exception x){
                Log.e("fuseLocationClient", "Error requesting location updates. Error: " + x);
                sendMessageToMain("Error requesting location updates. Error: " + x);
                generalHandler.postDelayed(reinitializeLocation,  1000);
            }
        }
    }

    //runs diagnostics in half a minute, if not already running
    //half minute delay is added to ensure that multiple calls do not come through at the same time from various sources
    final Runnable reinitializeLocation = new Runnable() {
        @Override
        public void run() {
            if(!diagnosisRunnableRunning){
                diagnosisRunnableRunning = true;
                Log.i("fuseLocationClient", "reinitialize location running");
                generalHandler.postDelayed(startRunningDiagnostics, 60 * 1000);
            }
        }
    };

    final Runnable startRunningDiagnostics = new Runnable() {
        @Override
        public void run() {
            runDiagnosticsMethods();
        }
    };

    //this runnable is called every 2 minutes after the location data is first called in order to establish that the data file is growing
    //if the data file does not grow after 6 minutes then diagnostics are run.
    private Runnable determineFileSize = new Runnable() {
        @Override
        public void run() {
            fileSizeAssessmentUnderway = true;

            database showDatabase = new database(fuseLocationClient.this);
            showDatabase.open();
            Long pastSizeOfDB = servicePreferences.getLong("file length", 0);
            Long newSizeOfDB = showDatabase.getDatabaseSize();
            if (pastSizeOfDB < newSizeOfDB) {
                Log.i("determineFileSize", "Increase in file size. File size - " + newSizeOfDB);
                editor.putLong("file length", newSizeOfDB);
                editor.putInt("number of failed updates", 0);
                editor.apply();
            } else {
                Log.i("determineFileSize", "No increase in file size File size - " + newSizeOfDB);
                if (servicePreferences.getInt("number of failed updates", 0) > 1) {
                    Log.e("determineFileSize", "consistent failing in increasing file size");
                    generalHandler.postDelayed(reinitializeLocation,  1000);
                }
                editor.putInt("number of failed updates", servicePreferences.getInt("number of failed updates", 0) + 1);
                editor.apply();
            }
            generalHandler.postDelayed(determineFileSize, 2 * 60 * 1000);
        }
    };

    //generates location data and stores them as a message, on the first instance of the data being called the title of the dataframes is stored
    LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            for (Location location : locationResult.getLocations()) {

                storeInSQL(location.getLatitude(), location.getLongitude(), location.getAccuracy(), location.getTime());

            }
        }
    };

    //stores the data into the internal database
    private void storeInSQL(double myLatitude, double myLongitude, float myAccuracy, long myTime) {
        database locationDatabaseStore = new database(this);
        locationDatabaseStore.open();
        locationDatabaseStore.addEntry(myLatitude, myLongitude, myAccuracy, myTime);
        locationDatabaseStore.close();

        sendMessageToMain("Data collection on going");
        if (!fileSizeAssessmentUnderway) {
            generalHandler.postDelayed(determineFileSize, 0);
        }
    }



    //securely stores data to internal storage

    /*
    private void toInternal(String message) {
        FileOutputStream fileOutputStream = null;
        try {
            Log.i("FuseLocationClient", "To internal: " + message);
            fileOutputStream = openFileOutput(geyer.location.android.peglog.Constants.FILE_NAME, MODE_APPEND);
            fileOutputStream.write(message.getBytes());
        } catch (IOException e) {
            Log.e("onLocationChanged", "Exception: " + e);
            sendMessageToMain("IOException at onLocationChanged: " + e);
        } finally {
            try {
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                sendMessageToMain("Data collection on going");
                if (!fileSizeAssessmentUnderway) {
                    generalHandler.postDelayed(determineFileSize, 0);
                }
            } catch (IOException e) {
                Log.e("onLocationChanged", "Point 5 exception: " + e);
                sendMessageToMain("IOException at onLocationChanged point 5: " + e);
            }
        }
    }

    */
    //determines if there are issues with signal, connection to internet, permissions or if google play requires update

    private void runDiagnosticsMethods() {

        String error = "";
        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);

        Boolean connectedToNetwork = true;
        if (tel != null) {
            Log.i("network connection", tel.getNetworkOperator());
        }else{
            Log.i("network connection", "NULL");
        }

        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            assert connectivityManager != null;
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            connectedToNetwork = networkInfo != null && networkInfo.isAvailable() && networkInfo.isConnected();
        } catch (Exception e) {
            Log.e("connectivityManager", "Issue identifying state of connectivity: " + e);
        }

        String airplaneModeString = Settings.System.AIRPLANE_MODE_ON;
        Log.i("airplaneMode", airplaneModeString);

        if (connectedToNetwork) {
            Boolean signalConnected = tel.getNetworkOperator() != null && !tel.getNetworkOperator().equals("");
            if (signalConnected) {
                checkPermissions();
            } else {
                error = "no signal connection";
                sendMessageToMain("error: " + error);
                storeErrorInSQL(error);
            }
        } else {
            error = "no network connection";
            sendMessageToMain("error: " + error);
            storeErrorInSQL(error);
        }

        initializeLocationUpdate();
        diagnosisRunnableRunning = false;
    }

    private void checkPermissions() {

        String results = "signal accessible, ";
        boolean runTimeLocationPermitted = true,
                gpsEnabled = false,
                networkEnable = false,
                locationPermissionGiven = true,
                locationManagerAccessible = true;

        //check runtime location permission given
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            runTimeLocationPermitted = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }

        //check if general location permission is given
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            locationPermissionGiven = locationSensingDetected();
        }

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager != null) {
            //is GPS enabled?
            gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            //is network enabled?
            networkEnable = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        }else{
            locationManagerAccessible = false;
        }

            //document all permissions provided
            if (runTimeLocationPermitted && gpsEnabled && networkEnable && locationPermissionGiven && locationManagerAccessible) {
                results += "no obvious cause of data problems - ";
            }

            //can the location manager be accessed?
            if(!locationManagerAccessible) {
                results += "location manager not accessible";
            }

            //general location permission?
            if (!locationPermissionGiven) {
                results += "location permission not given ";
            } else {
                results += "location permission given ";
            }

            //runtime location permission provided?
            if (!runTimeLocationPermitted) {
                results += "runtime permissions not given ";
            } else {
                results += "runtime permissions given ";
            }

            if (!gpsEnabled) {
                results += "gps not enabled ";
            } else {
                results += "GPS enabled ";
            }

            if (!networkEnable) {
                results += "network not enabled ";
            } else {
                results += "network enabled ";
            }

            storeErrorInSQL(results);
            sendMessageToMain(results);
            Log.e("Diagnostics", results);
        }

    private boolean locationSensingDetected() {
        boolean locationPermissionEnabled = true;
        try {
            int locationMode = Settings.Secure.getInt(getApplicationContext().getContentResolver(), Settings.Secure.LOCATION_MODE);
            locationPermissionEnabled = locationMode != Settings.Secure.LOCATION_MODE_OFF;
            Log.i("location permission", "given: " + locationPermissionEnabled);
        } catch (Settings.SettingNotFoundException e) {
            Log.e("Location Permission", "Failed to access location permissions. Error: " + e);
        }
        return locationPermissionEnabled;
    }

    private boolean detectGooglePlayUpdateRequired() {
        GoogleApiAvailability googleApiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = googleApiAvailability.isGooglePlayServicesAvailable(this);
        if (resultCode == ConnectionResult.SUCCESS) {
            return false;
        } else {
            if (googleApiAvailability.isUserResolvableError(resultCode)) {
                //have to record the error in an activity
                //use below code
                //googleApiAvailability.getErrorDialog(activity, resultCode, 2404);
                return true;
            }
            return true;
        }
    }
    //stores error reporting to the file named in constants class


    //stores the data into the internal database
    private void storeErrorInSQL(String error) {
        errorDatabase locationDatabaseStore = new errorDatabase(this);
        locationDatabaseStore.open();
        locationDatabaseStore.addEntry(error, System.currentTimeMillis());
        locationDatabaseStore.close();

        sendMessageToMain("Data collection on going");
        if (!fileSizeAssessmentUnderway) {
            generalHandler.postDelayed(determineFileSize, 0);
        }
    }


/*
    private void errorReport(String error) {
        FileOutputStream fileOutputStream = null;
        try {
            Log.i("FuseLocationClient", "Error detected in errorReporting: " + error);
            String toRelay = error + ": " + System.currentTimeMillis() + "\n";
            fileOutputStream = openFileOutput(Constants.ERROR_FILE_NAME, MODE_APPEND);
            fileOutputStream.write(toRelay.getBytes());
        } catch (IOException e) {
            Log.e("onLocationChanged", "Exception: " + e);
            sendMessageToMain("IOException at onLocationChanged: " + e);
        } finally {
            try {
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                sendMessageToMain("Error reported: " + error);
            } catch (IOException e) {
                Log.e("onLocationChanged", "Could not relay to internal: " + e);
                sendMessageToMain("Could not relay to internal due to - " + e + ". Error to relay: " + error);
            }
        }
    }

    */

    //relays messages to the main activity
    public void sendMessageToMain(String toRelay) {

        switch(toRelay){
            case "Restart service":

                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                Intent intent = new Intent("changeInService");
                intent.putExtra("killMain",false);
                intent.putExtra("timeToRestartService", true);
                intent.putExtra("locationDataCollectionBegan", false);
                LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
                Log.i("restart service", "instructed to restart service");
                break;
            case "kill main":
                Intent intent1 = new Intent("changeInService");
                intent1.putExtra("killMain",true);
                intent1.putExtra("timeToRestartService", false);
                intent1.putExtra("locationDataCollectionBegan", false);
                LocalBroadcastManager.getInstance(this).sendBroadcast(intent1);
                Log.i("collectingData", "instructed to kill main");
                break;
            default:
                Intent intent2 = new Intent("changeInService");
                intent2.putExtra("locationDataCollectionBegan", true);
                intent2.putExtra("Status", toRelay);
                LocalBroadcastManager.getInstance(this).sendBroadcast(intent2);
                Log.i("collectingData", "data sent to main");
                break;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //unregisters receiver when destroyed
    @Override
    public void onDestroy() {
        Log.i("fuseLocationClient", "On destroy called");
        unregisterReceiver(generalReceiver);
        unregisterReceiver(screenReceiver);

        if(fileSizeAssessmentUnderway){
            generalHandler.removeCallbacks(determineFileSize);
        }
        if(diagnosisRunnableRunning){
            generalHandler.removeCallbacks(startRunningDiagnostics);
            generalHandler.removeCallbacks(reinitializeLocation);
        }

        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
        super.onDestroy();
    }
}
